import { getStore } from "@netlify/blobs";
import { timingSafeEqual } from "node:crypto";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });

function samePin(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
}

function clean(data) {
  const links = Array.isArray(data?.links) ? data.links.slice(0, 500) : [];
  const out = [];
  for (const l of links) {
    if (!l || typeof l.name !== "string" || typeof l.url !== "string") continue;
    let u;
    try { u = new URL(l.url); } catch { continue; }
    if (u.protocol !== "http:" && u.protocol !== "https:") continue;
    out.push({
      id: String(l.id || "").slice(0, 40) || Math.random().toString(36).slice(2),
      name: l.name.slice(0, 80),
      url: u.href.slice(0, 2000),
      group: String(l.group || "").slice(0, 40),
      color: /^#[0-9a-f]{6}$/i.test(l.color || "") ? l.color : "#faae2b",
    });
  }
  return { links: out, tema: data?.tema === "dark" || data?.tema === "light" ? data.tema : "" };
}

export default async (req) => {
  const store = getStore({ name: "linksaya", consistency: "strong" });

  if (req.method === "GET") {
    const data = (await store.get("data", { type: "json" })) || { links: [], tema: "" };
    return json(data);
  }

  if (req.method === "POST") {
    const adminPin = process.env.ADMIN_PIN;
    if (!adminPin) return json({ error: "ADMIN_PIN belum diatur di Netlify" }, 500);

    let body;
    try { body = await req.json(); } catch { return json({ error: "Data tidak valid" }, 400); }

    if (!samePin(body?.pin ?? "", adminPin)) {
      await new Promise((r) => setTimeout(r, 1000)); // pelan-pelankan tebak PIN
      return json({ error: "PIN salah" }, 401);
    }
    if (body.action === "check") return json({ ok: true });

    await store.setJSON("data", clean(body.data));
    return json({ ok: true });
  }

  return json({ error: "Metode tidak didukung" }, 405);
};

export const config = { path: "/api/links" };
