# Link Saya (Netlify)

Isi paket:
- public/index.html          -> aplikasinya
- netlify/functions/links.mjs -> penyimpan data (Netlify Blobs) + cek PIN
- netlify.toml, package.json

## Cara pasang (lewat GitHub)
1. Buat repo baru di GitHub, unggah semua isi folder ini.
2. Di Netlify: Add new site > Import an existing project > pilih repo itu. Deploy.
3. Di Netlify: Site configuration > Environment variables > tambah
      ADMIN_PIN = 881988
4. Deploy ulang (Deploys > Trigger deploy) supaya PIN terbaca.
5. Buka situsnya > Pengaturan > masukkan PIN.

## Cara pasang (lewat CLI)
   npm i -g netlify-cli
   netlify login
   netlify init            # buat/sambungkan situs
   netlify env:set ADMIN_PIN 881988
   netlify deploy --prod

Catatan: PIN jangan ditulis di file HTML atau di repo, cukup di Environment variables.
Melihat menu tidak butuh PIN, mengubah menu butuh PIN.
